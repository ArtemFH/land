function Stores() {
    return (
        <>
            Stores
        </>
    )
}

export default Stores;
function Download() {
    return (
        <>
            Download
        </>
    )
}

export default Download;
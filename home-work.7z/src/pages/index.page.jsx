function Index() {
    return (
        <>
            Index
        </>
    )
}

export default Index;
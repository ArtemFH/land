function HelpSupport() {
    return (
        <>
            Help & Support
        </>
    )
}

export default HelpSupport;